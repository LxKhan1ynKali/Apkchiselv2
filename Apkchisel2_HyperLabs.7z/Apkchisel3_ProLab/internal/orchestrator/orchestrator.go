package orchestrator

import (
    "fmt"
    "os/exec"
    "os"
    "path/filepath"
)

func toolExists(name string) bool {
    _, err := exec.LookPath(name)
    return err == nil
}

func RunTools(apkPath, outDir string) {
    if toolExists("apktool") {
        apktoolOut := filepath.Join(outDir, "apktool_out")
        os.MkdirAll(apktoolOut, 0755)
        cmd := exec.Command("apktool", "d", apkPath, "-o", apktoolOut)
        out, err := cmd.CombinedOutput()
        if err != nil {
            fmt.Println("apktool error:", err)
        } else {
            fmt.Println("apktool output:", string(out))
        }
    } else {
        fmt.Println("apktool not found, skipping")
    }

    if toolExists("jadx") {
        jadxOut := filepath.Join(outDir, "jadx")
        os.MkdirAll(jadxOut, 0755)
        cmd := exec.Command("jadx", "-d", jadxOut, apkPath)
        out, err := cmd.CombinedOutput()
        if err != nil {
            fmt.Println("jadx error:", err)
        } else {
            fmt.Println("jadx output:", string(out))
        }
    } else {
        fmt.Println("jadx not found, skipping")
    }
}
