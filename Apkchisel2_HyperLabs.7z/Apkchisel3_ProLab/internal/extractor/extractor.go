package extractor

import (
    "archive/zip"
    "fmt"
    "io"
    "os"
    "path/filepath"
)

func ExtractAPK(apkPath, outDir string) ([]string, error) {
    r, err := zip.OpenReader(apkPath)
    if err != nil {
        return nil, err
    }
    defer r.Close()

    var files []string
    for _, f := range r.File {
        fmt.Println("Extracting:", f.Name)
        target := filepath.Join(outDir, f.Name)
        if f.FileInfo().IsDir() {
            os.MkdirAll(target, 0755)
            continue
        }
        os.MkdirAll(filepath.Dir(target), 0755)
        rc, err := f.Open()
        if err != nil {
            return files, err
        }
        outf, err := os.Create(target)
        if err != nil {
            rc.Close()
            return files, err
        }
        _, err = io.Copy(outf, rc)
        rc.Close()
        outf.Close()
        if err != nil {
            return files, err
        }
        files = append(files, target)
    }
    return files, nil
}
