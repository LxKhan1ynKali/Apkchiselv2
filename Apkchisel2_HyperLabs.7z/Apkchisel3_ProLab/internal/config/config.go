package config

type Config struct {
    APKPath    string
    OutputDir  string
    AIEndpoint string
    AIKey      string
    TimeoutMin int
    Workers    int
}
