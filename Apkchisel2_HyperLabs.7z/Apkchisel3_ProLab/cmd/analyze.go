package cmd

import (
    "apkchisel3_prolab/internal/extractor"
    "apkchisel3_prolab/internal/orchestrator"
    "apkchisel3_prolab/internal/ai"
    "apkchisel3_prolab/internal/utils"
    "fmt"
    "path/filepath"
    "sync"
)

type Config struct {
    APKPath    string
    OutputDir  string
    AIEndpoint string
    AIKey      string
    TimeoutMin int
    Workers    int
}

func Analyze(cfg Config) {
    utils.Log("Starting Apkchisel 3.1 Pro Lab analysis")

    // Extract APK
    extractDir := filepath.Join(cfg.OutputDir, "extracted")
    files, err := extractor.ExtractAPK(cfg.APKPath, extractDir)
    if err != nil {
        utils.Log(fmt.Sprintf("Extractor error: %v", err))
        return
    }
    utils.Log(fmt.Sprintf("Extracted %d files", len(files)))

    // Orchestrator
    orchestrator.RunTools(cfg.APKPath, cfg.OutputDir)

    // AI analysis (multi-threaded)
    if cfg.AIEndpoint != "" {
        utils.Log("Starting AI analysis with workers")
        sem := make(chan struct{}, cfg.Workers)
        var wg sync.WaitGroup

        for _, f := range files {
            if filepath.Ext(f) == ".java" || filepath.Ext(f) == ".smali" {
                wg.Add(1)
                go func(filePath string) {
                    defer wg.Done()
                    sem <- struct{}{}
                    ai.AnalyzeWithAI(filePath, cfg.AIEndpoint, cfg.AIKey)
                    <-sem
                }(f)
            }
        }
        wg.Wait()
        utils.Log("AI analysis completed")
    }

    utils.Log("Analysis finished")
}
