package main

import (
    "flag"
    "log"
    "os"
    "path/filepath"

    "apkchisel3_prolab/cmd"
)

func main() {
    apk := flag.String("apk", "", "APK file path")
    out := flag.String("out", "./analysis", "Output directory")
    aiURL := flag.String("ai-url", "", "Optional AI endpoint")
    aiKey := flag.String("ai-key", "", "Optional AI key")
    timeout := flag.Int("timeout", 10, "Timeout in minutes")
    workers := flag.Int("workers", 4, "Number of AI workers")
    flag.Parse()

    if *apk == "" {
        log.Fatal("Error: -apk flag is required")
    }

    absOut, _ := filepath.Abs(*out)
    os.MkdirAll(absOut, 0755)

    cfg := cmd.Config{
        APKPath:    *apk,
        OutputDir:  absOut,
        AIEndpoint: *aiURL,
        AIKey:      *aiKey,
        TimeoutMin: *timeout,
        Workers:    *workers,
    }

    cmd.Analyze(cfg)
}
